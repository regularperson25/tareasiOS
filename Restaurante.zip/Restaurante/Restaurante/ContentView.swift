//
//  ContentView.swift
//  Restaurante
//
//  Created by Carlos Arturo Lezama Garcia on 14/07/21.
//  Copyright © 2021 Carlos Arturo Lezama Garcia. All rights reserved.
//

import SwiftUI
//Root de la vista
struct BienvenidaView: View {
    var body: some View {
        NavigationView{
        VStack {
            Image("La humazon")
                .resizable()
                .scaledToFit()
            
            NavigationLink(destination: SelectionView(),
            label:{
                Text("Entrar")
                .bold()
                    .frame(width: 200, height: 50)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            })
            }
            .navigationBarTitle("Bienvenido")
        }
    }
}
//Seleccion de bebida/platillo
struct SelectionView: View {
    var body: some View {
        VStack {
            NavigationLink(destination: Bebidas(),
            label:{
                Image("Bebidas").renderingMode(.original)
            .resizable()
            .scaledToFit()
            })
            NavigationLink(destination: Platillos(),
                       label:{
            Image("Platillos").renderingMode(.original)
                .resizable()
                .scaledToFit()
            })
        }
    .navigationBarTitle("Seleccion")
    }
}
//Lista de platillos
struct Platillos: View {
    var body: some View {
       List {
        Text("Preferencia del Chef").bold().listRowBackground(Color.gray)
       NavigationLink(destination: CarneJugo(),
                      label:{
                    Text("Carne en su jugo")
       })
        NavigationLink(destination: BistecMex(),
                       label:{
                     Text("Bistec a la Mexicana")
        })
        NavigationLink(destination: Tomahawk(),
                       label:{
                     Text("Tomahawk")
        })
        
        Text("Los mas pedidos").bold().listRowBackground(Color.gray)
        NavigationLink(destination: Picaña(),
                       label:{
                     Text("Picaña")
        })
        NavigationLink(destination: Fajitas(),
                       label:{
                     Text("Fajitas de Res")
        })
        NavigationLink(destination: Cowboy(),
                       label:{
                     Text("Corte estilo Cowboy")
        })
       }
    }
}
//Lista de Bebidas
struct Bebidas: View {
    var body: some View {
       List {
        Text("Cervezas y Licores").bold().listRowBackground(Color.gray)
       NavigationLink(destination: CervezaA(),
                      label:{
                    Text("Cerveza Artesanal")
       })
        NavigationLink(destination: Whiskey(),
                       label:{
                     Text("Whisky Escoces")
        })
        NavigationLink(destination: Vino(),
                       label:{
                     Text("Vino Tinto")
        })
        
        Text("Para la familia").bold().listRowBackground(Color.gray)
        NavigationLink(destination: Limonada(),
                       label:{
                     Text("Limonada")
        })
        NavigationLink(destination: Jamaica(),
                       label:{
                     Text("Agua de Jamaica")
        })
        NavigationLink(destination: Horchata(),
                       label:{
                     Text("Agua de Horchata")
        })
       }
    }
}

//Vistas de los platillos
struct CarneJugo: View {
    var body: some View {
        VStack {
            Image("CarneJugo")
            Text("Deliciosa carne de chiva cocido en sus propios jugos carnicos y especiado con la receta secreta de La Humazon")
                .padding(.horizontal)
            Text("Precio: $130").bold()
            
            NavigationLink(destination: Reservacion(),
            label:{
                Text("Pedir Reservacion")
                .bold()
                    .frame(width: 200, height: 50)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }).padding(.top)
            
        }
    .navigationBarTitle("Carne en su Jugo")
    }
    
    
}

struct BistecMex: View {
    var body: some View {
        VStack {
            Image("BistecRes")
            Text("Suculento Bistec de Res acompañado de frijoles charros con papas fritas, aguacate y totopos")
                .padding(.horizontal)
            Text("Precio: $150").bold()
            
            NavigationLink(destination: Reservacion(),
            label:{
                Text("Pedir Reservacion")
                .bold()
                    .frame(width: 200, height: 50)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }).padding(.top)
            
        }
    .navigationBarTitle("Bistec a la Mexicana")
    }
}

struct Tomahawk: View {
var body: some View {
    VStack {
        Image("Tomahawk")
        Text("Corte Tomahawk acompañado de sazon secreto de La Humazon con verduras al vapor y una ligera embarrada de nuestra salsa habanera toreada casera")
            .padding(.horizontal)
        Text("Precio: $1200").bold()
        
        NavigationLink(destination: Reservacion(),
        label:{
            Text("Pedir Reservacion")
            .bold()
                .frame(width: 200, height: 50)
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
        }).padding(.top)
        
    }
.navigationBarTitle("Tomahawk")
    }
}

struct Picaña: View {
var body: some View {
    VStack {
        Image("picaña")
        Text("Picaña de res marinado de nuestra receta secreta a termino medio y chiles asados")
            .padding(.horizontal)
        Text("Precio: $200").bold()
        
        NavigationLink(destination: Reservacion(),
        label:{
            Text("Pedir Reservacion")
            .bold()
                .frame(width: 200, height: 50)
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
        }).padding(.top)
        
    }
.navigationBarTitle("Picaña")
    }
}

struct Fajitas: View {
var body: some View {
    VStack {
        Image("fajitas")
        Text("Fajitas estilo casero marinado con nuestra receta secreta acompañado de cebolla y tortillas calientitas hechas a mano")
            .padding(.horizontal)
        Text("Precio: $80").bold()
        
        NavigationLink(destination: Reservacion(),
        label:{
            Text("Pedir Reservacion")
            .bold()
                .frame(width: 200, height: 50)
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
        }).padding(.top)
        
    }
.navigationBarTitle("Fajitas de Res")
    }
}

struct Cowboy: View {
var body: some View {
    VStack {
        Image("Cowboy")
        Text("Corte estilo Cowboy marinado con la receta secreta acompañado de crujientes papas fritas")
            .padding(.horizontal)
        Text("Precio: $500").bold()
        
        NavigationLink(destination: Reservacion(),
        label:{
            Text("Pedir Reservacion")
            .bold()
                .frame(width: 200, height: 50)
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
        }).padding(.top)
        
    }
.navigationBarTitle("Cowboy")
    }
}

//Vista de las Bebidas
struct CervezaA: View {
var body: some View {
    VStack {
        Image("CervezaA")
        Text("Cerveza artesanal hecho en barriles de cedro con fondo ahumado para darle a nuestro brebaje un peculiar sabor aromatico sureño servido en tarro de cristal artesanal")
            .padding(.horizontal)
        Text("Precio: $80").bold()
        
        NavigationLink(destination: Reservacion(),
        label:{
            Text("Pedir Reservacion")
            .bold()
                .frame(width: 200, height: 50)
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
        }).padding(.top)
        
    }
.navigationBarTitle("Cerveza Artesanal Ahumado")
    }
}

struct Whiskey: View {
var body: some View {
    VStack {
        Image("Whiskey")
        Text("Delicioso Whiskey local de la Whiskeria Don Ernesto hecho con malta de cosecha local")
            .padding(.horizontal)
        Text("Precio: $80").bold()
        
        NavigationLink(destination: Reservacion(),
        label:{
            Text("Pedir Reservacion")
            .bold()
                .frame(width: 200, height: 50)
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
        }).padding(.top)
        
    }
.navigationBarTitle("Whiskey Don Ernesto")
    }
}

struct Vino: View {
var body: some View {
    VStack {
        Image("Vino")
        Text("Vino artesanal hecho de uva de las llanuras del sureste de sabor suave")
            .padding(.horizontal)
        Text("Precio: $60").bold()
        
        NavigationLink(destination: Reservacion(),
        label:{
            Text("Pedir Reservacion")
            .bold()
                .frame(width: 200, height: 50)
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
        }).padding(.top)
        
    }
.navigationBarTitle("Vino Artesanal")
    }
}

struct Limonada: View {
var body: some View {
    VStack {
        Image("Limonada")
        Text("Agua de limon criollo")
            .padding(.horizontal)
        Text("Precio: $20 vaso / 100 jarra").bold()
        
        NavigationLink(destination: Reservacion(),
        label:{
            Text("Pedir Reservacion")
            .bold()
                .frame(width: 200, height: 50)
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
        }).padding(.top)
        
    }
.navigationBarTitle("Limonada")
    }
}

struct Jamaica: View {
var body: some View {
    VStack {
        Image("Jamaica")
        Text("Agua de Jamaica fresca")
            .padding(.horizontal)
        Text("Precio: $20 vaso / 100 jarra").bold()
        
        NavigationLink(destination: Reservacion(),
        label:{
            Text("Pedir Reservacion")
            .bold()
                .frame(width: 200, height: 50)
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
        }).padding(.top)
        
    }
.navigationBarTitle("Jamaica")
    }
}

struct Horchata: View {
var body: some View {
    VStack {
        Image("Horchata")
        Text("Agua de Horchata casera")
            .padding(.horizontal)
        Text("Precio: $20 vaso / 100 jarra").bold()
        
        NavigationLink(destination: Reservacion(),
        label:{
            Text("Pedir Reservacion")
            .bold()
                .frame(width: 200, height: 50)
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
        }).padding(.top)
        
    }
.navigationBarTitle("Horchata")
    }
}

struct Reservacion: View {
    var body: some View {
        VStack {
            Image("Reservacion").resizable().scaledToFit()
            Text("Selecciona la fecha y hora de reservacion a desear").bold().padding(.top)
                .padding(.horizontal)
            DatePicker(selection: /*@START_MENU_TOKEN@*/.constant(Date())/*@END_MENU_TOKEN@*/, label: { Text("Fecha") }).padding()
            NavigationLink(destination: Reservado(),
            label:{
                Text("Reservar")
                .bold()
                    .frame(width: 200, height: 50)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }).padding(.top).padding(.bottom)
        }
    .navigationBarTitle("Reservacion")
    }
}

struct Reservado: View {
var body: some View {
    VStack {
        Image("Check")
        Text("Gracias por reservar")
            .padding(.horizontal)
        NavigationLink(destination: SelectionView(),
        label:{
            Text("Inicio")
            .bold()
                .frame(width: 200, height: 50)
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
        }).padding(.top).padding(.bottom)
        
    }
.navigationBarTitle("")
    }
}



struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        BienvenidaView()
    }
}
