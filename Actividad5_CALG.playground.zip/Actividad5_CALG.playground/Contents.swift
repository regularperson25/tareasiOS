import UIKit

//1. Declaracion de clase persona
class Persona
{
    var saludar = ""
    var caminar = 0
    
    init(saludar:String, caminar:Int)
    {
        self.saludar = saludar
        self.caminar = caminar
    }
    func Caminar(pasos:Int)
    {
        self.caminar = pasos
    }
    func Hablar(nombre:String)
    {
        self.saludar = nombre
    }
}
//Instanciar e inicializar los metodos
var Carlos = Persona(saludar: "", caminar: 0)
Carlos.Caminar(pasos: 1200)
Carlos.Hablar(nombre: "Carlos")

//Impresion y aplicacion
print("Mi mensaje es \(Carlos.saludar), como te encuentras el dia de hoy?")
print("La verdad yo cansado, caminando de alla para aca unos \(Carlos.caminar) pasos")

//2. Declaracion del Struct Pantalla

struct Pantalla
{
    var height:Int
    var width:Int
    
    init(height:Int, width:Int)
    {
        self.height = height
        self.width = width
    }
    
    func Res() -> (Int, Int)
    {
        return (self.height, self.width)
    }
}
//Estructurar
var FourK = Pantalla(height:4096, width:2160)
print("La resolucion de la pantalla es \(FourK.Res())")

//3. Extension
extension Int
{
    var horaseg:Int
    {
        return self*3600
    }
}
print("La conversion de 5 horas a segundos equivale a \(5.horaseg)")

//4. Opcional

var numero = ["1":1, "2":2, "3":3]
var existe:Int?
if numero["4"] != nil
{
    print("Al parecer dentro del arreglo de numeros[1, 2, 3] el valor: 4 Si existe")
}
else
{
    print("Al parecer dentro del arreglo de numeros[1, 2, 3] el valor: 4 No existe")
}

var dias = ["GDL":120, "PUE":300, "MTY":100, "CDMX":200]
if let dias = dias["DF"]
{
    print("Existe y tiene \(dias) dias")
}
else
{
    print("No existe amigo, lo siento")
}
