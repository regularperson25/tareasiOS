//
//  ViewController.swift
//  Actividad9
//
//  Created by Carlos Arturo Lezama Garcia on 22/07/21.
//  Copyright © 2021 Carlos Arturo Lezama Garcia. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

