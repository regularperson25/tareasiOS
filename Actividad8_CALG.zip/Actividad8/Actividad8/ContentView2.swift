//  ContentView2.swift
//  Actividad8
//
//  Created by Carlos Arturo Lezama Garcia on 22/07/21.
//  Copyright © 2021 Carlos Arturo Lezama Garcia. All rights reserved.
//

import SwiftUI

struct ContentView2: View {
    var body: some View {
        Image("img2")            .resizable()
            .scaledToFill()
    }
}

struct ContentView2_Previews: PreviewProvider {
    static var previews: some View {
        ContentView2()
    }
}
