//
//  ContentView.swift
//  Actividad8
//
//  Created by Carlos Arturo Lezama Garcia on 21/07/21.
//  Copyright © 2021 Carlos Arturo Lezama Garcia. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
		Image("img1.PNG")
			.resizable()
			.scaledToFill()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
