//
//  ContentView3.swift
//  Actividad8
//
//  Created by Carlos Arturo Lezama Garcia on 22/07/21.
//  Copyright © 2021 Carlos Arturo Lezama Garcia. All rights reserved.
//

import SwiftUI

struct ContentView3: View {
    var body: some View {
        Image("img3.PNG")
        .resizable()
        .scaledToFill()

    }
}

struct ContentView3_Previews: PreviewProvider {
    static var previews: some View {
        ContentView3()
    }
}
