//
//  ContentView5.swift
//  Actividad8
//
//  Created by Carlos Arturo Lezama Garcia on 22/07/21.
//  Copyright © 2021 Carlos Arturo Lezama Garcia. All rights reserved.
//

import SwiftUI

struct ContentView5: View {
    var body: some View {
        Image("img5")
        .resizable()
        .scaledToFill()
    }
}

struct ContentView5_Previews: PreviewProvider {
    static var previews: some View {
        ContentView5()
    }
}
