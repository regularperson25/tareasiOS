//: Playground - noun: a place where people can play

import UIKit

//Arreglo y condicionales
var datos:Array = [3,6,9,2,4,1]
var x = 0;

repeat{
    
    if datos [x] < 5 {
    print ("Es menor de 5")
}
else{
    print ("No es menor de 5")
    }
   x = x + 1
}while x <= 5

//Funcion suma
func suma(var1:Int, var2:Int) ->Int {return var1 + var2}
suma(var1:6,var2:14)

//Funcion Potencia
func poten(base:Double, pot:Double) ->Double{return pow(Double(base), Double(pot))}
poten(base:3, pot:4)
