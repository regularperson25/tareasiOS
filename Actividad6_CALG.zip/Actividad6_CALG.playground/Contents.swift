import UIKit

/*: 
### Operadores personalizados
A) Crear el operador para realizar la potencia de el valor "a" a la potencia "b" en valores enteros
*/
infix operator **

func **(a:Int, b:Int) -> Int
{
    return Int(pow(Double(a), Double(b)))
    
}
let res1 = 2 ** 4
//: B) Crear el operador |> para ordenar la colección [2,5,3,4] de menor a mayor
prefix operator |>

prefix func |> (array: [Int]) -> [Int]
{
    let orden = array.sorted()
    return orden
}

let numeros = |>[2,5,3,4]

/*:
### Subscripts
A) Del conjunto de datos en el Array [2,3,4,5], crear el subscript para modificar los valores multiplicados por el valor 2 y extraer al valor dado un índice.
*/
let cants = [2,3,4,5]

class Cant
{
    var ValuesA:[Int]
    init (v:[Int])
    {
        self.ValuesA = v
    }
    
    subscript(idx:Int) -> Int
    {
        get
        {
            return ValuesA[idx]*2
        }
        set(NewValA)
        {
            ValuesA[idx] = NewValA
        }
    }
   
}

let VR = Cant(v: cants)
VR[3]

//: B) Crear el Struct para definir u obtener la posición  para los personaje de tipo Enemigo donde cada posición es de tipo CGPoint aplicnado subscritps
let enemie1 = (x:10, y:10)

struct Enems{
    //let point: CGPoint = CGPoint(x:10,y:10)
    //var enemie1:CGpoint(x: Int, y:Int)
    var position:[CGPoint]
    subscript(x:Int, y:Int) -> [Int]
    {
        get{
            position[x,y]
        }
        set
        {
            
        }
    }
    
}

/*:
### Control de Errores
A) Crear la función ExisteValor en la cual se reciba como parámetro el valor a buscar dentro de un colección ["A":1, "B":2,"C":3]
*/









